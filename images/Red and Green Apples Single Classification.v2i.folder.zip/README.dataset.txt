# Red and Green Apples Single Classification > 2022-12-29 11:15pm
https://universe.roboflow.com/apples-1lrlt/red-and-green-apples-single-classification

Provided by a Roboflow user
License: CC BY 4.0

